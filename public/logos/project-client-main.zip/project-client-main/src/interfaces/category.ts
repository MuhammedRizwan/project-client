export interface Category {
    _id: string;
    category_name: string;
    description: string;
    image: string;
    is_block: boolean;
}