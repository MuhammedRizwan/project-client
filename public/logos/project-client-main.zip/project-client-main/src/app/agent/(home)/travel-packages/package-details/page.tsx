
const PackageDetails = () => {
    return (
      <div>
        <h1>Package Details</h1>
      </div>
    );
  };
  
  export default PackageDetails;
  