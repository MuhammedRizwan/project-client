import {Spinner} from "@nextui-org/react";

export default function Spinnerpage() {
  return (
    <Spinner label="Loading..." color="danger" />
  );
}